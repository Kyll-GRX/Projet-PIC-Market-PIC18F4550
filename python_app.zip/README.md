# Cashier application (basis)

Cross-platform cashier software (Windows, macOS, Linux) written in Python with Tkinter.
It runs the sale on the computer and drives the cashier board over a serial/USB link.

## Run it

1. Install Python 3.8 or newer (Tkinter is included on Windows and macOS; on Debian/Ubuntu run `sudo apt install python3-tk`).
2. For a real board: `pip install -r requirements.txt` (installs pyserial).
3. Start: `python main.py`

Without a board, keep the Hardware tab on "Simulator": every command that would go to the board is shown in the communication log, and you can inject keypad or scanner input by hand.

## Files

- `main.py` - the window: Sale, Products, Reports and Hardware tabs
- `core.py` - money, cart, SQLite database, receipt and day-report text (no GUI, easy to test)
- `hardware.py` - serial protocol and the simulator
- `config.json` - shop name, address, currency, VAT, receipt width, serial port (created on first run)
- `data/cashier.db` - products and sales; `data/receipts/` - a text copy of every receipt and day report

## Board protocol (placeholder, adapt to the firmware)

One text line per message, ending with `\n`, 115200 baud by default.

| Direction | Message | Meaning |
|---|---|---|
| PC -> board | `PING` | connection check, board answers `PONG` |
| PC -> board | `DRAWER:OPEN` | pulse the cash drawer |
| PC -> board | `DISPLAY:line1\|line2` | customer display (16 chars per line by default) |
| PC -> board | `PRINT:text` | print one receipt line |
| PC -> board | `CUT` | feed and cut paper |
| PC -> board | `BEEP` | buzzer |
| board -> PC | `KEY:x` | keypad: `0`-`9`, `.`, `ENTER`, `CLR`, `DEL`, `CASH`, `CARD` |
| board -> PC | `SCAN:code` | barcode |
| board -> PC | `DRAWER:OPEN` / `DRAWER:CLOSED` | drawer switch |
| board -> PC | `OK`, `PONG`, `ERR:message` | replies |

All of it lives in `hardware.py`, so changing the protocol does not touch the rest of the app.

## Keyboard shortcuts

Enter adds the typed code, F5 cash payment, F6 card payment, Delete removes the selected line, Escape returns to the code field.
