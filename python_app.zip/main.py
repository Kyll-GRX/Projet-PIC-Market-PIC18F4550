#!/usr/bin/env python3
"""
Cashier application - cross-platform (Windows, macOS, Linux).
Only needs Python 3.8+ with Tkinter. pyserial is needed for real hardware.

Run:  python main.py
"""

import json
import queue
import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import messagebox, ttk

from core import (Cart, Database, Product, build_day_report, build_receipt,
                  fmt_money, parse_money)
from hardware import (SERIAL_AVAILABLE, HardwareEvent, SerialDevice,
                      SimulatedDevice, list_serial_ports)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RECEIPT_DIR = DATA_DIR / "receipts"
CONFIG_PATH = BASE_DIR / "config.json"

DEFAULT_CONFIG = {
    "shop_name": "My Shop",
    "shop_address_lines": ["1 High Street", "London"],
    "currency_symbol": "€",
    "vat_rate_percent": 20,
    "receipt_width": 32,
    "receipt_footer": "Thank you for your visit!",
    "cash_quick_amounts": [5, 10, 20, 50],
    "quick_items": 12,
    "hardware": {
        "mode": "simulator",   # "simulator" or "serial"
        "port": "",
        "baudrate": 115200,
        "display_width": 16,
    },
}


def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            user = json.load(f)
        hw = user.pop("hardware", {})
        cfg.update(user)
        cfg["hardware"].update(hw)
    except FileNotFoundError:
        save_config(cfg)
    except (json.JSONDecodeError, OSError) as exc:
        print(f"config.json could not be read ({exc}), using defaults.")
    return cfg


def save_config(cfg: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


# ====================================================================== dialogs
class CashDialog(tk.Toplevel):
    """Asks the amount handed over by the customer and shows the change."""

    def __init__(self, parent, total_cents: int, symbol: str, quick_amounts):
        super().__init__(parent)
        self.title("Cash payment")
        self.transient(parent)
        self.resizable(False, False)
        self.result = None
        self.total = total_cents
        self.symbol = symbol

        frm = ttk.Frame(self, padding=16)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text=f"Total due: {fmt_money(total_cents, symbol)}",
                  font=("Helvetica", 16, "bold")).grid(row=0, column=0, columnspan=5, sticky="w")

        ttk.Label(frm, text="Amount received").grid(row=1, column=0, sticky="w", pady=(12, 4))
        self.amount_var = tk.StringVar(value=fmt_money(total_cents))
        entry = ttk.Entry(frm, textvariable=self.amount_var, font=("Helvetica", 16), width=12)
        entry.grid(row=1, column=1, columnspan=4, sticky="ew", pady=(12, 4))

        ttk.Button(frm, text="Exact", command=lambda: self.amount_var.set(fmt_money(total_cents))
                   ).grid(row=2, column=0, sticky="ew", padx=2)
        for i, amount in enumerate(quick_amounts[:4], start=1):
            ttk.Button(frm, text=f"{symbol}{amount}",
                       command=lambda a=amount: self.amount_var.set(fmt_money(int(a * 100)))
                       ).grid(row=2, column=i, sticky="ew", padx=2)

        self.change_var = tk.StringVar()
        ttk.Label(frm, textvariable=self.change_var, font=("Helvetica", 14)
                  ).grid(row=3, column=0, columnspan=5, sticky="w", pady=12)

        btns = ttk.Frame(frm)
        btns.grid(row=4, column=0, columnspan=5, sticky="e")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Take payment", command=self._ok).pack(side="right")

        self.amount_var.trace_add("write", lambda *_: self._update_change())
        entry.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self.destroy())
        self._update_change()

        self.wait_visibility()
        self.grab_set()
        entry.focus_set()
        entry.select_range(0, "end")
        self.wait_window()

    def _value(self):
        try:
            return parse_money(self.amount_var.get())
        except ValueError:
            return None

    def _update_change(self):
        v = self._value()
        if v is None:
            self.change_var.set("Enter a valid amount")
        elif v < self.total:
            self.change_var.set(f"Missing {fmt_money(self.total - v, self.symbol)}")
        else:
            self.change_var.set(f"Change to give: {fmt_money(v - self.total, self.symbol)}")

    def _ok(self):
        v = self._value()
        if v is None or v < self.total:
            self.bell()
            return
        self.result = v
        self.destroy()


# ====================================================================== app
class CashierApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.sym = self.cfg["currency_symbol"]
        self.title(f"{self.cfg['shop_name']} - Cashier")
        self.geometry("1150x720")
        self.minsize(950, 600)

        RECEIPT_DIR.mkdir(parents=True, exist_ok=True)
        self.db = Database(DATA_DIR / "cashier.db")
        self.cart = Cart()
        self.device = None
        self.log_queue: "queue.Queue[str]" = queue.Queue()
        self.event_queue: "queue.Queue[HardwareEvent]" = queue.Queue()
        self._last_hw_status = None

        self._build_ui()
        self._connect_device()
        self.after(50, self._poll)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------ UI build
    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", rowheight=26)
        style.configure("Total.TLabel", font=("Helvetica", 34, "bold"))
        style.configure("Pay.TButton", font=("Helvetica", 15, "bold"), padding=12)
        style.configure("Error.TLabel", foreground="#b3261e")

        bar = ttk.Frame(self, padding=(10, 4))
        bar.pack(side="bottom", fill="x")
        self.status_var = tk.StringVar(value="Ready")
        self.status_label = ttk.Label(bar, textvariable=self.status_var)
        self.status_label.pack(side="left")
        self.hw_status_var = tk.StringVar()
        ttk.Label(bar, textvariable=self.hw_status_var).pack(side="right")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True)
        self.tab_sale = ttk.Frame(nb, padding=10)
        self.tab_products = ttk.Frame(nb, padding=10)
        self.tab_reports = ttk.Frame(nb, padding=10)
        self.tab_hardware = ttk.Frame(nb, padding=10)
        nb.add(self.tab_sale, text="  Sale  ")
        nb.add(self.tab_products, text="  Products  ")
        nb.add(self.tab_reports, text="  Reports  ")
        nb.add(self.tab_hardware, text="  Hardware  ")

        self._build_sale_tab()
        self._build_products_tab()
        self._build_reports_tab()
        self._build_hardware_tab()

    def _build_sale_tab(self):
        f = self.tab_sale
        f.columnconfigure(0, weight=3)
        f.columnconfigure(1, weight=2)
        f.rowconfigure(1, weight=1)

        row = ttk.Frame(f)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(row, text="Code / barcode").pack(side="left")
        self.code_var = tk.StringVar()
        self.code_entry = ttk.Entry(row, textvariable=self.code_var, width=18, font=("Helvetica", 14))
        self.code_entry.pack(side="left", padx=6)
        self.code_entry.bind("<Return>", lambda _e: self._on_code_enter())
        ttk.Label(row, text="Qty").pack(side="left", padx=(10, 0))
        self.qty_var = tk.StringVar(value="1")
        ttk.Spinbox(row, from_=1, to=999, textvariable=self.qty_var, width=5).pack(side="left", padx=6)
        ttk.Button(row, text="Add", command=self._on_code_enter).pack(side="left")

        holder = ttk.Frame(f)
        holder.grid(row=1, column=0, sticky="nsew")
        holder.rowconfigure(0, weight=1)
        holder.columnconfigure(0, weight=1)
        cols = ("code", "name", "qty", "unit", "total")
        self.cart_tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="browse")
        for col, text, width, anchor in [("code", "Code", 90, "w"), ("name", "Product", 260, "w"),
                                         ("qty", "Qty", 60, "center"), ("unit", "Unit price", 100, "e"),
                                         ("total", "Line total", 110, "e")]:
            self.cart_tree.heading(col, text=text)
            self.cart_tree.column(col, width=width, anchor=anchor, stretch=(col == "name"))
        self.cart_tree.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.cart_tree.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.cart_tree.configure(yscrollcommand=sb.set)
        self.cart_tree.bind("<Delete>", lambda _e: self._remove_line())

        btns = ttk.Frame(f)
        btns.grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Button(btns, text="+1", width=4, command=lambda: self._change_qty(1)).pack(side="left")
        ttk.Button(btns, text="-1", width=4, command=lambda: self._change_qty(-1)).pack(side="left", padx=4)
        ttk.Button(btns, text="Remove line", command=self._remove_line).pack(side="left", padx=4)
        ttk.Button(btns, text="Cancel sale", command=self._cancel_sale).pack(side="left", padx=4)

        right = ttk.Frame(f, padding=(16, 0, 0, 0))
        right.grid(row=0, column=1, rowspan=3, sticky="nsew")
        ttk.Label(right, text="Total").pack(anchor="e")
        self.total_var = tk.StringVar()
        ttk.Label(right, textvariable=self.total_var, style="Total.TLabel").pack(anchor="e")
        self.items_var = tk.StringVar()
        ttk.Label(right, textvariable=self.items_var).pack(anchor="e", pady=(0, 12))
        ttk.Button(right, text="Cash  (F5)", style="Pay.TButton",
                   command=lambda: self._pay("cash")).pack(fill="x", pady=3)
        ttk.Button(right, text="Card  (F6)", style="Pay.TButton",
                   command=lambda: self._pay("card")).pack(fill="x", pady=3)
        ttk.Label(right, text="Quick items").pack(anchor="w", pady=(18, 4))
        self.quick_frame = ttk.Frame(right)
        self.quick_frame.pack(fill="both", expand=True)

        self.bind("<F5>", lambda _e: self._pay("cash"))
        self.bind("<F6>", lambda _e: self._pay("card"))
        self.bind("<Escape>", lambda _e: self.code_entry.focus_set())

        self._refresh_cart()
        self._refresh_quick_buttons()
        self.code_entry.focus_set()

    def _build_products_tab(self):
        f = self.tab_products
        f.columnconfigure(0, weight=1)
        f.rowconfigure(0, weight=1)

        cols = ("code", "name", "price", "stock")
        self.prod_tree = ttk.Treeview(f, columns=cols, show="headings", selectmode="browse")
        for col, text, width, anchor in [("code", "Code", 110, "w"), ("name", "Name", 280, "w"),
                                         ("price", "Price", 100, "e"), ("stock", "Stock", 90, "e")]:
            self.prod_tree.heading(col, text=text)
            self.prod_tree.column(col, width=width, anchor=anchor, stretch=(col == "name"))
        self.prod_tree.grid(row=0, column=0, sticky="nsew")
        self.prod_tree.bind("<<TreeviewSelect>>", lambda _e: self._on_product_select())

        form = ttk.LabelFrame(f, text="Product", padding=12)
        form.grid(row=0, column=1, sticky="n", padx=(12, 0))
        self.p_vars = {k: tk.StringVar() for k in ("code", "name", "price", "stock")}
        for i, (key, label) in enumerate([("code", "Code / barcode"), ("name", "Name"),
                                          ("price", f"Price ({self.sym}, VAT incl.)"), ("stock", "Stock")]):
            ttk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=3)
            ttk.Entry(form, textvariable=self.p_vars[key], width=24).grid(row=i, column=1, pady=3)
        ttk.Label(form, text="Leave stock empty if you don't track it.",
                  foreground="#666").grid(row=4, column=0, columnspan=2, sticky="w", pady=(4, 10))
        b = ttk.Frame(form)
        b.grid(row=5, column=0, columnspan=2, sticky="e")
        ttk.Button(b, text="New", command=self._clear_product_form).pack(side="left")
        ttk.Button(b, text="Save product", command=self._save_product).pack(side="left", padx=4)
        ttk.Button(b, text="Delete", command=self._delete_product).pack(side="left")
        self._refresh_products()

    def _build_reports_tab(self):
        f = self.tab_reports
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(top, text="Day (YYYY-MM-DD)").pack(side="left")
        self.report_day_var = tk.StringVar(value=date.today().isoformat())
        ttk.Entry(top, textvariable=self.report_day_var, width=12).pack(side="left", padx=6)
        ttk.Button(top, text="Show", command=self._refresh_reports).pack(side="left")
        ttk.Button(top, text="Today", command=self._report_today).pack(side="left", padx=4)
        ttk.Button(top, text="Print day report", command=self._print_day_report).pack(side="right")

        cols = ("id", "time", "method", "total", "tendered", "change")
        self.sales_tree = ttk.Treeview(f, columns=cols, show="headings")
        for col, text, width, anchor in [("id", "Sale #", 70, "center"), ("time", "Time", 100, "center"),
                                         ("method", "Payment", 100, "center"), ("total", "Total", 110, "e"),
                                         ("tendered", "Received", 110, "e"), ("change", "Change", 110, "e")]:
            self.sales_tree.heading(col, text=text)
            self.sales_tree.column(col, width=width, anchor=anchor)
        self.sales_tree.grid(row=1, column=0, sticky="nsew")

        self.summary_var = tk.StringVar()
        ttk.Label(f, textvariable=self.summary_var, font=("Helvetica", 13)
                  ).grid(row=2, column=0, sticky="w", pady=(10, 0))
        self._refresh_reports()

    def _build_hardware_tab(self):
        f = self.tab_hardware
        f.columnconfigure(0, weight=1)
        f.rowconfigure(3, weight=1)
        hw = self.cfg["hardware"]

        conn = ttk.LabelFrame(f, text="Connection", padding=10)
        conn.grid(row=0, column=0, sticky="ew")
        self.hw_mode_var = tk.StringVar(value=hw["mode"])
        ttk.Radiobutton(conn, text="Simulator (no hardware)", value="simulator",
                        variable=self.hw_mode_var).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(conn, text="Serial port", value="serial",
                        variable=self.hw_mode_var).grid(row=0, column=1, sticky="w", padx=(16, 0))
        self.port_var = tk.StringVar(value=hw["port"])
        self.port_combo = ttk.Combobox(conn, textvariable=self.port_var, width=22)
        self.port_combo.grid(row=0, column=2, padx=6)
        ttk.Button(conn, text="Refresh ports", command=self._refresh_ports).grid(row=0, column=3)
        ttk.Label(conn, text="Baud").grid(row=0, column=4, padx=(12, 4))
        self.baud_var = tk.StringVar(value=str(hw["baudrate"]))
        ttk.Combobox(conn, textvariable=self.baud_var, width=8,
                     values=["9600", "19200", "38400", "57600", "115200"]).grid(row=0, column=5)
        ttk.Button(conn, text="Connect", command=self._connect_device).grid(row=0, column=6, padx=(12, 4))
        ttk.Button(conn, text="Disconnect", command=self._disconnect_device).grid(row=0, column=7)
        if not SERIAL_AVAILABLE:
            ttk.Label(conn, text="pyserial is not installed: run  pip install pyserial  to use a real board.",
                      style="Error.TLabel").grid(row=1, column=0, columnspan=8, sticky="w", pady=(8, 0))
        self._refresh_ports()

        test = ttk.LabelFrame(f, text="Test the hardware", padding=10)
        test.grid(row=1, column=0, sticky="ew", pady=8)
        ttk.Button(test, text="Ping", command=lambda: self._hw("ping")).pack(side="left")
        ttk.Button(test, text="Open drawer", command=lambda: self._hw("open_drawer")).pack(side="left", padx=4)
        ttk.Button(test, text="Beep", command=lambda: self._hw("beep")).pack(side="left")
        ttk.Button(test, text="Display test", command=lambda: self._hw(
            "show_display", "Display test", "0123456789ABCDEF")).pack(side="left", padx=4)
        ttk.Button(test, text="Print test", command=lambda: self._hw(
            "print_receipt", "Printer test\n" + "-" * self.cfg["receipt_width"] + "\nOK")).pack(side="left")

        sim = ttk.LabelFrame(f, text="Simulate board input (keypad / scanner)", padding=10)
        sim.grid(row=2, column=0, sticky="ew")
        self.sim_var = tk.StringVar()
        ttk.Entry(sim, textvariable=self.sim_var, width=20).pack(side="left")
        ttk.Button(sim, text="Send as SCAN", command=lambda: self._simulate("SCAN")).pack(side="left", padx=4)
        ttk.Button(sim, text="Send as KEY", command=lambda: self._simulate("KEY")).pack(side="left")
        ttk.Label(sim, text="Keys: 0-9  .  ENTER  CLR  DEL  CASH  CARD",
                  foreground="#666").pack(side="left", padx=12)

        logf = ttk.LabelFrame(f, text="Communication log", padding=6)
        logf.grid(row=3, column=0, sticky="nsew", pady=(8, 0))
        logf.rowconfigure(0, weight=1)
        logf.columnconfigure(0, weight=1)
        self.log_text = tk.Text(logf, height=10, state="disabled", font=("Courier", 10), wrap="none")
        self.log_text.grid(row=0, column=0, sticky="nsew")
        lsb = ttk.Scrollbar(logf, orient="vertical", command=self.log_text.yview)
        lsb.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=lsb.set)
        ttk.Button(logf, text="Clear log", command=self._clear_log).grid(row=1, column=0, sticky="e", pady=(4, 0))

    # ------------------------------------------------------------ helpers
    def _set_status(self, text: str, error: bool = False):
        self.status_var.set(text)
        self.status_label.configure(style="Error.TLabel" if error else "TLabel")

    def _log(self, text: str):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        if int(self.log_text.index("end-1c").split(".")[0]) > 2000:
            self.log_text.delete("1.0", "500.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _hw(self, action: str, *args):
        """Send a command to the board if connected; never crashes the sale."""
        dev = self.device
        if dev is None or not dev.is_connected():
            return
        try:
            getattr(dev, action)(*args)
        except Exception as exc:
            self._log(f"Hardware error during {action}: {exc}")

    def _show_total_on_display(self, first_line: str):
        self._hw("show_display", first_line, f"Total {fmt_money(self.cart.total_cents)}")

    # ------------------------------------------------------------ sale
    def _on_code_enter(self):
        try:
            qty = max(1, int(self.qty_var.get()))
        except ValueError:
            qty = 1
        self._add_by_code(self.code_var.get(), qty)
        self.code_var.set("")
        self.qty_var.set("1")
        self.code_entry.focus_set()

    def _add_by_code(self, code: str, qty: int = 1):
        code = code.strip()
        if not code:
            return
        product = self.db.get_product(code)
        if product is None:
            self._set_status(f"Unknown product code: {code}", error=True)
            self._hw("beep")
            return
        self.cart.add(product, qty)
        self._refresh_cart(select_code=code)
        self._set_status(f"Added {qty} x {product.name}")
        if product.stock is not None and product.stock < self._qty_in_cart(code):
            self._set_status(f"Added {product.name} - warning: only {product.stock} in stock", error=True)
        self._show_total_on_display(product.name)

    def _qty_in_cart(self, code: str) -> int:
        return sum(l.qty for l in self.cart.lines if l.product.code == code)

    def _selected_index(self):
        sel = self.cart_tree.selection()
        return int(sel[0]) if sel else None

    def _change_qty(self, delta: int):
        idx = self._selected_index()
        if idx is None:
            return
        code = self.cart.lines[idx].product.code
        self.cart.change_qty(idx, delta)
        self._refresh_cart(select_code=code)
        self._show_total_on_display("Updated")

    def _remove_line(self):
        idx = self._selected_index()
        if idx is None:
            return
        self.cart.remove(idx)
        self._refresh_cart()
        self._show_total_on_display("Item removed")

    def _cancel_sale(self):
        if self.cart.is_empty():
            return
        if messagebox.askyesno("Cancel sale", "Remove all items from the current sale?"):
            self.cart.clear()
            self._refresh_cart()
            self._set_status("Sale cancelled")
            self._hw("show_display", self.cfg["shop_name"], "Welcome")

    def _refresh_cart(self, select_code: str = None):
        self.cart_tree.delete(*self.cart_tree.get_children())
        for i, line in enumerate(self.cart.lines):
            p = line.product
            self.cart_tree.insert("", "end", iid=str(i), values=(
                p.code, p.name, line.qty, fmt_money(p.price_cents, self.sym),
                fmt_money(line.total_cents, self.sym)))
            if p.code == select_code:
                self.cart_tree.selection_set(str(i))
                self.cart_tree.see(str(i))
        self.total_var.set(fmt_money(self.cart.total_cents, self.sym))
        n = self.cart.item_count
        self.items_var.set(f"{n} item{'s' if n != 1 else ''}")

    def _refresh_quick_buttons(self):
        for w in self.quick_frame.winfo_children():
            w.destroy()
        for i, p in enumerate(self.db.list_products()[: self.cfg["quick_items"]]):
            ttk.Button(self.quick_frame, text=f"{p.name}\n{fmt_money(p.price_cents, self.sym)}",
                       command=lambda c=p.code: self._add_by_code(c, 1)
                       ).grid(row=i // 3, column=i % 3, sticky="nsew", padx=2, pady=2, ipady=6)
        for c in range(3):
            self.quick_frame.columnconfigure(c, weight=1)

    def _pay(self, method: str):
        if self.cart.is_empty():
            self._set_status("The sale is empty", error=True)
            return
        total = self.cart.total_cents
        if method == "cash":
            tendered = CashDialog(self, total, self.sym, self.cfg["cash_quick_amounts"]).result
            if tendered is None:
                return
        else:
            if not messagebox.askyesno(
                    "Card payment",
                    f"Charge {fmt_money(total, self.sym)} by card?\n\n"
                    "Confirm only once the card terminal shows APPROVED."):
                return
            tendered = total
        change = tendered - total

        lines = list(self.cart.lines)
        try:
            sale_id, when = self.db.record_sale(self.cart, method, tendered, change)
        except Exception as exc:
            messagebox.showerror("Error", f"The sale could not be saved:\n{exc}")
            return

        receipt = build_receipt(self.cfg, sale_id, lines, total, method, tendered, change, when)
        try:
            (RECEIPT_DIR / f"receipt_{sale_id:06d}.txt").write_text(receipt, encoding="utf-8")
        except OSError as exc:
            self._log(f"Could not save receipt file: {exc}")

        if method == "cash":
            self._hw("open_drawer")
        self._hw("print_receipt", receipt)
        self._hw("show_display", "Thank you!",
                 f"Change {fmt_money(change)}" if method == "cash" else "Paid by card")

        self.cart.clear()
        self._refresh_cart()
        self._refresh_products()
        self._refresh_reports()
        self._set_status(f"Sale #{sale_id} done - {fmt_money(total, self.sym)} by {method}")
        if method == "cash" and change > 0:
            messagebox.showinfo("Change", f"Give change: {fmt_money(change, self.sym)}")
        self.code_entry.focus_set()

    # ------------------------------------------------------------ products
    def _refresh_products(self):
        self.prod_tree.delete(*self.prod_tree.get_children())
        for p in self.db.list_products():
            self.prod_tree.insert("", "end", iid=p.code, values=(
                p.code, p.name, fmt_money(p.price_cents, self.sym),
                "-" if p.stock is None else p.stock))

    def _on_product_select(self):
        sel = self.prod_tree.selection()
        if not sel:
            return
        p = self.db.get_product(sel[0])
        if p:
            self.p_vars["code"].set(p.code)
            self.p_vars["name"].set(p.name)
            self.p_vars["price"].set(fmt_money(p.price_cents))
            self.p_vars["stock"].set("" if p.stock is None else str(p.stock))

    def _clear_product_form(self):
        for v in self.p_vars.values():
            v.set("")
        self.prod_tree.selection_remove(*self.prod_tree.selection())

    def _save_product(self):
        code = self.p_vars["code"].get().strip()
        name = self.p_vars["name"].get().strip()
        if not code or not name:
            messagebox.showwarning("Product", "Code and name are required.")
            return
        try:
            price = parse_money(self.p_vars["price"].get())
        except ValueError:
            messagebox.showwarning("Product", "The price is not valid (example: 2.50).")
            return
        stock_text = self.p_vars["stock"].get().strip()
        try:
            stock = int(stock_text) if stock_text else None
        except ValueError:
            messagebox.showwarning("Product", "Stock must be a whole number, or empty.")
            return
        self.db.upsert_product(Product(code, name, price, stock))
        self._refresh_products()
        self._refresh_quick_buttons()
        self._set_status(f"Product {code} saved")

    def _delete_product(self):
        code = self.p_vars["code"].get().strip()
        if not code or self.db.get_product(code) is None:
            return
        if messagebox.askyesno("Delete product", f"Delete product {code}?"):
            self.db.delete_product(code)
            self._clear_product_form()
            self._refresh_products()
            self._refresh_quick_buttons()
            self._set_status(f"Product {code} deleted")

    # ------------------------------------------------------------ reports
    def _report_day(self):
        try:
            return date.fromisoformat(self.report_day_var.get().strip())
        except ValueError:
            self._set_status("Invalid date, use YYYY-MM-DD", error=True)
            return None

    def _report_today(self):
        self.report_day_var.set(date.today().isoformat())
        self._refresh_reports()

    def _refresh_reports(self):
        day = self._report_day()
        if day is None:
            return
        self.sales_tree.delete(*self.sales_tree.get_children())
        for s in self.db.sales_for_day(day):
            self.sales_tree.insert("", "end", values=(
                s["id"], s["timestamp"][11:19], s["payment_method"],
                fmt_money(s["total_cents"], self.sym), fmt_money(s["tendered_cents"], self.sym),
                fmt_money(s["change_cents"], self.sym)))
        summary = self.db.day_summary(day)
        n = sum(v[0] for v in summary.values())
        total = sum(v[1] for v in summary.values())
        parts = [f"{m}: {fmt_money(t, self.sym)} ({c})" for m, (c, t) in sorted(summary.items())]
        self.summary_var.set(f"{n} sales - total {fmt_money(total, self.sym)}"
                             + ("   |   " + "   ".join(parts) if parts else ""))

    def _print_day_report(self):
        day = self._report_day()
        if day is None:
            return
        report = build_day_report(self.cfg, day, self.db.day_summary(day))
        path = RECEIPT_DIR / f"report_{day.isoformat()}.txt"
        try:
            path.write_text(report, encoding="utf-8")
        except OSError as exc:
            self._log(f"Could not save report: {exc}")
        self._hw("print_receipt", report)
        self._set_status(f"Day report saved to {path.name}")

    # ------------------------------------------------------------ hardware
    def _refresh_ports(self):
        ports = list_serial_ports()
        self.port_combo["values"] = ports
        if not self.port_var.get() and ports:
            self.port_var.set(ports[0])

    def _connect_device(self):
        self._disconnect_device()
        hw = self.cfg["hardware"]
        mode = self.hw_mode_var.get()
        kwargs = dict(on_log=self.log_queue.put, on_event=self.event_queue.put,
                      display_width=hw.get("display_width", 16))
        if mode == "serial":
            port = self.port_var.get().strip()
            if not port:
                self._set_status("Choose a serial port first (Hardware tab)", error=True)
                return
            try:
                baud = int(self.baud_var.get())
            except ValueError:
                self._set_status("Invalid baud rate", error=True)
                return
            dev = SerialDevice(port, baud, **kwargs)
        else:
            dev = SimulatedDevice(**kwargs)

        try:
            dev.connect()
        except Exception as exc:
            self.log_queue.put(f"Connection failed: {exc}")
            self._set_status(f"Hardware connection failed: {exc}", error=True)
            return
        self.device = dev

        hw["mode"] = mode
        if mode == "serial":
            hw["port"], hw["baudrate"] = dev.port, dev.baudrate
        try:
            save_config(self.cfg)
        except OSError:
            pass
        self._hw("show_display", self.cfg["shop_name"], "Welcome")

    def _disconnect_device(self):
        if self.device is not None:
            try:
                self.device.disconnect()
            except Exception as exc:
                self.log_queue.put(f"Disconnect error: {exc}")
            self.device = None

    def _simulate(self, kind: str):
        value = self.sim_var.get().strip()
        if value:
            self.log_queue.put(f"[SIM] << {kind}:{value}")
            self.event_queue.put(HardwareEvent(kind, value))
            self.sim_var.set("")

    def _handle_event(self, ev: HardwareEvent):
        kind, value = ev.kind, ev.value.strip()
        if kind == "SCAN":
            self._add_by_code(value, 1)
        elif kind == "KEY":
            key = value.upper()
            if key.isdigit() or key == ".":
                self.code_var.set(self.code_var.get() + key)
            elif key in ("ENTER", "OK"):
                self._on_code_enter()
            elif key in ("CLR", "CLEAR"):
                self.code_var.set("")
            elif key == "DEL":
                self._remove_line()
            elif key == "CASH":
                self.after(0, lambda: self._pay("cash"))
            elif key == "CARD":
                self.after(0, lambda: self._pay("card"))
        elif kind == "DRAWER":
            self._set_status(f"Drawer {value.lower()}")
        elif kind == "ERR":
            self._set_status(f"Board error: {value}", error=True)

    def _poll(self):
        """Runs every 50 ms in the GUI thread: handles messages from the serial thread."""
        try:
            while True:
                self._log(self.log_queue.get_nowait())
        except queue.Empty:
            pass
        try:
            while True:
                self._handle_event(self.event_queue.get_nowait())
        except queue.Empty:
            pass

        dev = self.device
        status = (f"Hardware: {dev.label} - connected" if dev and dev.is_connected()
                  else "Hardware: not connected")
        if status != self._last_hw_status:
            self.hw_status_var.set(status)
            self._last_hw_status = status
        self.after(50, self._poll)

    def _on_close(self):
        if not self.cart.is_empty() and not messagebox.askyesno(
                "Quit", "A sale is in progress. Quit anyway?"):
            return
        self._disconnect_device()
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    CashierApp().mainloop()
