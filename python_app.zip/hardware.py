"""
Hardware layer: talks to the cashier board (microcontroller) over a serial port.

PROTOCOL (placeholder - adapt it to your firmware / pin-assignment guidelines)
Line-based text, UTF-8, one message per line, terminated by '\\n'.

PC -> board
  PING                  connection check, the board answers PONG
  DRAWER:OPEN           pulse the cash-drawer solenoid
  DISPLAY:<l1>|<l2>     customer display, two lines
  PRINT:<text>          print one line on the receipt printer
  CUT                   feed and cut the paper
  BEEP                  short buzzer beep

board -> PC
  KEY:<k>               keypad key: 0-9, ., ENTER, CLR, DEL, CASH, CARD
  SCAN:<code>           barcode read by the scanner
  DRAWER:OPEN|CLOSED    drawer switch state
  OK / PONG / ERR:<message>
"""

import threading
from dataclasses import dataclass
from typing import Callable, List, Optional

try:
    import serial
    import serial.tools.list_ports
    SERIAL_AVAILABLE = True
except ImportError:  # the app still runs in simulator mode without pyserial
    serial = None
    SERIAL_AVAILABLE = False


class HardwareError(Exception):
    pass


@dataclass
class HardwareEvent:
    kind: str
    value: str = ""


def list_serial_ports() -> List[str]:
    if not SERIAL_AVAILABLE:
        return []
    return [p.device for p in serial.tools.list_ports.comports()]


def _clean(text: str, strip_bar: bool = False) -> str:
    """Remove characters that would break the line-based protocol."""
    text = str(text).replace("\r", " ").replace("\n", " ")
    if strip_bar:
        text = text.replace("|", "/")
    return text


class BaseDevice:
    """Common commands. Subclasses only implement the transport (_send etc.)."""

    def __init__(self, on_log: Callable[[str], None],
                 on_event: Callable[[HardwareEvent], None],
                 display_width: int = 16):
        self.on_log = on_log
        self.on_event = on_event
        self.display_width = display_width

    # --- transport, implemented by subclasses ---
    @property
    def label(self) -> str:
        return "device"

    def connect(self):
        raise NotImplementedError

    def disconnect(self):
        raise NotImplementedError

    def is_connected(self) -> bool:
        raise NotImplementedError

    def _send(self, command: str, payload: Optional[str] = None):
        raise NotImplementedError

    @staticmethod
    def _format(command: str, payload: Optional[str]) -> str:
        return f"{command}:{payload}" if payload is not None else command

    # --- high-level commands used by the app ---
    def ping(self):
        self._send("PING")

    def open_drawer(self):
        self._send("DRAWER", "OPEN")

    def beep(self):
        self._send("BEEP")

    def show_display(self, line1: str, line2: str = ""):
        w = self.display_width
        l1 = _clean(line1, strip_bar=True)[:w]
        l2 = _clean(line2, strip_bar=True)[:w]
        self._send("DISPLAY", f"{l1}|{l2}")

    def print_receipt(self, text: str):
        for line in text.splitlines():
            self._send("PRINT", _clean(line) if line.strip() else " ")
        self._send("CUT")


class SimulatedDevice(BaseDevice):
    """No hardware needed: every command is written to the log instead."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._connected = False

    @property
    def label(self) -> str:
        return "Simulator"

    def connect(self):
        self._connected = True
        self.on_log("[SIM] Simulator connected (no real hardware).")

    def disconnect(self):
        if self._connected:
            self._connected = False
            self.on_log("[SIM] Simulator disconnected.")

    def is_connected(self) -> bool:
        return self._connected

    def _send(self, command: str, payload: Optional[str] = None):
        self.on_log(f"[SIM] >> {self._format(command, payload)}")
        if command == "PING":
            self.on_event(HardwareEvent("PONG"))


class SerialDevice(BaseDevice):
    """Real board on a serial / USB-serial port (COM3 on Windows, /dev/ttyUSB0 on Linux...)."""

    def __init__(self, port: str, baudrate: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.port = port
        self.baudrate = baudrate
        self._ser = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    @property
    def label(self) -> str:
        return f"Serial {self.port} @ {self.baudrate}"

    def connect(self):
        if not SERIAL_AVAILABLE:
            raise HardwareError("pyserial is not installed. Run: pip install pyserial")
        try:
            self._ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
        except (serial.SerialException, OSError) as exc:
            raise HardwareError(f"Cannot open {self.port}: {exc}") from exc
        self._running = True
        self._thread = threading.Thread(target=self._reader, daemon=True)
        self._thread.start()
        self.on_log(f"Connected to {self.port} at {self.baudrate} baud.")
        self.ping()

    def disconnect(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=1)
            self._thread = None
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
            self._ser = None
            self.on_log(f"Disconnected from {self.port}.")

    def is_connected(self) -> bool:
        return self._running and self._ser is not None and self._ser.is_open

    def _send(self, command: str, payload: Optional[str] = None):
        line = self._format(command, payload)
        if not self.is_connected():
            self.on_log(f"(not connected, dropped) {line}")
            return
        try:
            with self._lock:
                self._ser.write((line + "\n").encode("utf-8"))
            self.on_log(f">> {line}")
        except (serial.SerialException, OSError) as exc:
            self._running = False
            self.on_log(f"Write error: {exc}")

    def _reader(self):
        """Runs in a background thread: reads lines and turns them into events."""
        buffer = b""
        while self._running:
            try:
                chunk = self._ser.read(64)
            except (serial.SerialException, OSError) as exc:
                self.on_log(f"Serial error, connection lost: {exc}")
                self._running = False
                break
            if not chunk:
                continue
            buffer += chunk
            while b"\n" in buffer:
                raw, buffer = buffer.split(b"\n", 1)
                text = raw.decode("utf-8", errors="replace").strip()
                if text:
                    self.on_log(f"<< {text}")
                    kind, _, value = text.partition(":")
                    self.on_event(HardwareEvent(kind.strip().upper(), value.strip()))
