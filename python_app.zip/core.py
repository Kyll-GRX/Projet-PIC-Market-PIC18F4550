"""
Core cashier logic, independent from the GUI and the hardware:
money handling, cart, SQLite storage, receipts and day reports.
Money is always stored as integer cents to avoid rounding errors.
"""

import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------- money
def parse_money(text: str) -> int:
    """'12.5', '12,50', '12.50€' -> 1250 cents."""
    cleaned = str(text).strip().replace(",", ".")
    for symbol in "€ ":
        cleaned = cleaned.replace(symbol, "€")
    try:
        value = Decimal(cleaned)
    except InvalidOperation:
        raise ValueError(f"Invalid amount: {text!r}")
    if value < 0:
        raise ValueError("Amount cannot be negative")
    return int((value * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def fmt_money(cents: int, symbol: str = "") -> str:
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    return f"{sign}{symbol}{cents // 100}.{cents % 100:02d}"


def vat_included(total_cents: int, rate_percent: float) -> int:
    """VAT part of a VAT-inclusive price."""
    if not rate_percent:
        return 0
    return int(round(total_cents * rate_percent / (100 + rate_percent)))


# ---------------------------------------------------------------- models
@dataclass
class Product:
    code: str
    name: str
    price_cents: int
    stock: Optional[int] = None  # None = stock not tracked


@dataclass
class CartLine:
    product: Product
    qty: int

    @property
    def total_cents(self) -> int:
        return self.product.price_cents * self.qty


@dataclass
class Cart:
    lines: List[CartLine] = field(default_factory=list)

    def add(self, product: Product, qty: int = 1):
        for line in self.lines:
            if line.product.code == product.code:
                line.qty += qty
                return
        self.lines.append(CartLine(product, qty))

    def change_qty(self, index: int, delta: int):
        line = self.lines[index]
        line.qty += delta
        if line.qty <= 0:
            del self.lines[index]

    def remove(self, index: int):
        del self.lines[index]

    def clear(self):
        self.lines.clear()

    def is_empty(self) -> bool:
        return not self.lines

    @property
    def total_cents(self) -> int:
        return sum(line.total_cents for line in self.lines)

    @property
    def item_count(self) -> int:
        return sum(line.qty for line in self.lines)


# ---------------------------------------------------------------- database
DEMO_PRODUCTS = [
    Product("1001", "Coffee", 250, None),
    Product("1002", "Tea", 200, None),
    Product("1003", "Croissant", 180, 30),
    Product("1004", "Sandwich", 450, 20),
    Product("1005", "Water 50cl", 120, 48),
    Product("1006", "Orange juice", 300, 24),
]


class Database:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self._create_schema()

    def _create_schema(self):
        with self.conn:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS products (
                    code TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    price_cents INTEGER NOT NULL,
                    stock INTEGER
                );
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    total_cents INTEGER NOT NULL,
                    payment_method TEXT NOT NULL,
                    tendered_cents INTEGER NOT NULL,
                    change_cents INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sale_items (
                    sale_id INTEGER NOT NULL REFERENCES sales(id),
                    code TEXT NOT NULL,
                    name TEXT NOT NULL,
                    qty INTEGER NOT NULL,
                    unit_cents INTEGER NOT NULL
                );
            """)
        if self.conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            for p in DEMO_PRODUCTS:
                self.upsert_product(p)

    @staticmethod
    def _row_to_product(row) -> Product:
        return Product(row["code"], row["name"], row["price_cents"], row["stock"])

    # products
    def get_product(self, code: str) -> Optional[Product]:
        row = self.conn.execute("SELECT * FROM products WHERE code = ?", (code,)).fetchone()
        return self._row_to_product(row) if row else None

    def list_products(self) -> List[Product]:
        rows = self.conn.execute("SELECT * FROM products ORDER BY code").fetchall()
        return [self._row_to_product(r) for r in rows]

    def upsert_product(self, p: Product):
        with self.conn:
            self.conn.execute(
                "INSERT INTO products(code, name, price_cents, stock) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(code) DO UPDATE SET name = excluded.name, "
                "price_cents = excluded.price_cents, stock = excluded.stock",
                (p.code, p.name, p.price_cents, p.stock))

    def delete_product(self, code: str):
        with self.conn:
            self.conn.execute("DELETE FROM products WHERE code = ?", (code,))

    # sales
    def record_sale(self, cart: Cart, method: str, tendered: int, change: int) -> Tuple[int, datetime]:
        now = datetime.now()
        with self.conn:  # one transaction: everything is saved, or nothing
            cur = self.conn.execute(
                "INSERT INTO sales(timestamp, total_cents, payment_method, tendered_cents, change_cents) "
                "VALUES (?, ?, ?, ?, ?)",
                (now.isoformat(timespec="seconds"), cart.total_cents, method, tendered, change))
            sale_id = cur.lastrowid
            self.conn.executemany(
                "INSERT INTO sale_items(sale_id, code, name, qty, unit_cents) VALUES (?, ?, ?, ?, ?)",
                [(sale_id, l.product.code, l.product.name, l.qty, l.product.price_cents) for l in cart.lines])
            self.conn.executemany(
                "UPDATE products SET stock = stock - ? WHERE code = ? AND stock IS NOT NULL",
                [(l.qty, l.product.code) for l in cart.lines])
        return sale_id, now

    def sales_for_day(self, day: date) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM sales WHERE substr(timestamp, 1, 10) = ? ORDER BY id",
            (day.isoformat(),)).fetchall()

    def day_summary(self, day: date) -> Dict[str, Tuple[int, int]]:
        rows = self.conn.execute(
            "SELECT payment_method, COUNT(*) AS n, SUM(total_cents) AS total FROM sales "
            "WHERE substr(timestamp, 1, 10) = ? GROUP BY payment_method",
            (day.isoformat(),)).fetchall()
        return {r["payment_method"]: (r["n"], r["total"] or 0) for r in rows}

    def close(self):
        self.conn.close()


# ---------------------------------------------------------------- receipts
def _row(left: str, right: str, width: int) -> str:
    left = left[: max(0, width - len(right) - 1)]
    return left + " " * (width - len(left) - len(right)) + right


def _header(cfg: dict) -> List[str]:
    w = cfg["receipt_width"]
    lines = [cfg["shop_name"][:w].center(w)]
    lines += [a[:w].center(w) for a in cfg.get("shop_address_lines", [])]
    lines.append("-" * w)
    return lines


def build_receipt(cfg: dict, sale_id: int, lines: List[CartLine], total: int,
                  method: str, tendered: int, change: int, when: datetime) -> str:
    w, sym = cfg["receipt_width"], cfg["currency_symbol"]
    out = _header(cfg)
    out += [f"Sale #{sale_id}", when.strftime("%d/%m/%Y %H:%M:%S"), "-" * w]
    for line in lines:
        out.append(line.product.name[:w])
        out.append(_row(f"  {line.qty} x {fmt_money(line.product.price_cents)}",
                        fmt_money(line.total_cents, sym), w))
    out.append("-" * w)
    out.append(_row("TOTAL", fmt_money(total, sym), w))
    rate = cfg.get("vat_rate_percent", 0)
    if rate:
        out.append(_row(f"incl. VAT {rate}%", fmt_money(vat_included(total, rate), sym), w))
    out.append(_row(f"Paid ({method})", fmt_money(tendered, sym), w))
    if method == "cash":
        out.append(_row("Change", fmt_money(change, sym), w))
    out += ["-" * w, cfg["receipt_footer"][:w].center(w)]
    return "\n".join(out)


def build_day_report(cfg: dict, day: date, summary: Dict[str, Tuple[int, int]]) -> str:
    w, sym = cfg["receipt_width"], cfg["currency_symbol"]
    out = _header(cfg)
    out += ["DAY REPORT".center(w), day.strftime("%d/%m/%Y").center(w), "-" * w]
    total_n = total = 0
    for method, (n, amount) in sorted(summary.items()):
        out.append(_row(f"{method} ({n})", fmt_money(amount, sym), w))
        total_n += n
        total += amount
    out.append("-" * w)
    out.append(_row(f"TOTAL ({total_n} sales)", fmt_money(total, sym), w))
    rate = cfg.get("vat_rate_percent", 0)
    if rate:
        out.append(_row(f"incl. VAT {rate}%", fmt_money(vat_included(total, rate), sym), w))
    out.append(_row("Printed", datetime.now().strftime("%H:%M"), w))
    return "\n".join(out)
