# PIC MARKET – Sauvegarde « défense 1, scanner OK » (26/10/2026, build de 23:05)

**Dernier état validé sur carte** : le **vrai scanner** Waveshare envoie le code-barres
au PIC, qui affiche l'article + prix + total sur le GLCD, déclenche bip + LED, et
renvoie le résultat au GUI Python, qui met à jour le panier. Le bouton RE2 vide le panier.

Le `.hex` de ce dossier est **celui qui a été flashé** à 23:05 : les sources de ce
dossier, recompilées avec les options de MPLAB, redonnent ce `.hex` **octet pour octet**.

## Contenu du dossier

| Fichier | Rôle |
|---|---|
| `firmware/ecran_code.c` | programme principal (UART, base produits, feedbacks, écrans, bouton RE2) |
| `firmware/glcd.c`, `glcd.h` | pilote GLCD 128x64 KS0108 (busy flag, `GLCD_CS_ACTIVE 0`) |
| `firmware/PIC_MARKET_scanner_OK.hex` | **binaire testé** : à reflasher tel quel avec mikroProg Suite |
| `python_gui/pic_market_gui.py` | interface caisse (customtkinter + pyserial) |
| `python_gui/lancer_gui.bat` | lancement du GUI par double-clic |
| `projet_scanner_1.X_MPLAB_complet.zip` | projet MPLAB X complet avec ces sources |

## Revenir à cet état

- **Le plus rapide** : flasher directement `firmware/PIC_MARKET_scanner_OK.hex`.
- **Pour retravailler le code** : copier `ecran_code.c`, `glcd.c`, `glcd.h` dans
  `C:\Users\robin\MPLABXProjects\projet_scanner_ 1.X` (en écrasant), puis *Clean and Build*.
  Le fichier `catalog.h` éventuellement présent dans le projet n'est alors plus utilisé.
- Pour le GUI : remettre `pic_market_gui.py` de ce dossier dans `python_gui`.

## Différences avec la sauvegarde précédente (`simulation_OK`, 19:46)

| Ajout | Pourquoi |
|---|---|
| LF (`0x0A`) ignoré à la réception | tolère un scanner réglé en CR+LF |
| Bouton **RE2** = nouvelle transaction (`Cart_Reset`) | avec le scanner sur RC7, le PC ne peut plus envoyer `RESET` (TS1.9) |

## Matériel et brochage (EasyPIC v7 + PIC18F4550, quartz **8 MHz**)

| Fonction | Broches |
|---|---|
| GLCD données | PORTD (RD0–RD7) |
| GLCD contrôle | RB0 CS1, RB1 CS2, RB2 RS, RB3 RW, RB4 EN, RB5 RST |
| Scanner → PIC | **RC7** (RX), 9600 bauds 8N1, fin de code = CR |
| PIC → PC | **RC6** (TX) → module USB-UART |
| Buzzer | RC2 (PWM CCP1) — 2,5 kHz connu, 1,5 kHz inconnu |
| LEDs / bouton | RE0 verte, RE1 rouge, RE2 bouton panier |

Scanner (connecteur PORTC) : **VCC → +5 V**, **GND → GND**, **TXD → RC7**, RXD non relié.

## Réglages de la carte (check-list)

- [ ] Socket **DIP40**, quartz 8 MHz, jumper d'alim sur **USB** (chargeur ≥ 1 A conseillé : le scanner tire 210 mA)
- [ ] Jumper **J21** (buzzer) sur **RC2**
- [ ] LEDs **PORTE** : ON — pull-down **PORTE** : ON (bouton RE2), BUTTON PRESS LEVEL sur VCC
- [ ] LEDs et pull-up/down **PORTB / PORTD** : OFF (bus du GLCD) — **DIS0–DIS3** : OFF
- [ ] Rétroéclairage : **BCK ON**, **BPWM OFF**
- [ ] Module USB-UART : **RC6 ON**, **RC7 OFF** (RC7 est réservé au scanner)
- [ ] LEDs et pull de **RC7** (PORTC) : OFF
- [ ] Scanner réglé en **sortie UART** (code « UART Output », p. 14 du Setting Manual V2.1, dans `docs/`)
- [ ] **Après tout changement d'interrupteur : couper puis rétablir l'alimentation**

Mode simulation sans scanner : débrancher le scanner et mettre **RC7 ON** ; les boutons du GUI
envoient alors les codes au PIC.

## Protocole (UART 9600 8N1)

| Sens | Trame | Signification |
|---|---|---|
| Scanner (ou PC) → PIC | `<code>\r` | code ASCII terminé par CR (0x0D) |
| PC → PIC | `RESET\r` | vide le panier (mode simulation seulement) |
| PIC → PC | `PIC MARKET pret\r\n` | au démarrage |
| PIC → PC | `FOUND;<nom>;<prix>\r\n` | produit connu |
| PIC → PC | `UNKNOWN;<code>\r\n` | produit inconnu |
| PIC → PC | `RESET;OK\r\n` | panier vidé (bouton RE2 ou commande RESET) |

## Problèmes rencontrés et solutions

| Symptôme | Cause | Solution |
|---|---|---|
| Scanner muet, timings ×2, bip grave (code du camarade) | code calculé pour 16 MHz, carte à 8 MHz → UART à 4800 bauds | SPBRG = 207, duties buzzer 25/42, délais pour 8 MHz |
| Produits réels toujours « inconnus » (code du camarade) | test fictif `rx_buffer[0] == '1'` | vraie recherche `strcmp()` dans `catalog[]` |
| Aucun son, aucune LED | J21 absent, LEDs PORTE désactivées | J21 sur RC2, LED PORTE ON |
| GLCD noir | rétroéclairage relié à RC2 (BPWM) | BPWM OFF, BCK ON |
| Écran plein mais pas de texte | contrôleur GLCD bloqué | coupure d'alim + pilote avec busy flag |
| Moitiés gauche/droite inversées | chip-select actifs à l'état bas | `GLCD_CS_ACTIVE 0` |
| Scanner ne parle pas au PIC | sortie USB par défaut / conflit sur RC7 | code « UART Output », switch RC7 du USB-UART sur OFF |

## Après cette sauvegarde (non testé)

Le projet MPLAB et le GUI contiennent ensuite la fonction « Nouvel article » : base
`produits.json` éditable dans le GUI, `catalog.h` généré automatiquement, tampon de
64 caractères pour les QR codes. **Elle n'a pas encore été testée sur la carte.**

## Utilisation de l'IA (à reporter dans le rapport — politique « niveau 2 »)

Code et diagnostic réalisés avec l'assistance de Claude (Anthropic) dans Claude Code :
pilote GLCD, intégration UART/buzzer/LED/base produits à partir du code du camarade
(adapté de 16 à 8 MHz), interface Python, diagnostic par compilation et simulation,
vidéo explicative. Tests et validation sur carte réalisés par l'équipe.
À compléter selon ce que vous avez effectivement modifié vous-mêmes.
