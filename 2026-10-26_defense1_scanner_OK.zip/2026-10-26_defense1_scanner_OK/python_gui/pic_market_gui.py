"""
PIC MARKET - Interface GUI (defense 1)
--------------------------------------
Simule le scanner : on envoie un code-barres au PIC via le module USB-UART
de l'EasyPIC v7 (port COM virtuel, 9600 8N1). Le PIC repond "FOUND;nom;prix"
ou "UNKNOWN;code", ce qui alimente le panier ci-dessous.

Prerequis (une seule fois) :
    pip install pyserial customtkinter

Lancement :
    python pic_market_gui.py
"""

import queue
import threading

try:
    import customtkinter as ctk
except ImportError:
    raise SystemExit("Module manquant : lance  pip install customtkinter")

from tkinter import ttk

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    raise SystemExit("Module manquant : lance  pip install pyserial")

BAUD = 9600

# Doit refleter la base produits du firmware (meme codes / prix)
CATALOG = [
    ("3017620422003", "Nutella 400g",   3.45),
    ("5449000000996", "Coca-Cola 1.5L", 1.80),
    ("3228857000906", "Baguette",       0.95),
    ("8000500310427", "Kinder Bueno",   1.20),
    ("20001",         "Pommes 1kg",     2.50),
    ("0000000000000", "Produit test KO", 0.0),  # volontairement inconnu du PIC
]


class PicMarketGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("PIC MARKET - Caisse")
        self.geometry("620x560")
        ctk.set_appearance_mode("system")

        self.ser = None
        self.rx_queue = queue.Queue()
        self.reader_thread = None
        self.running = False
        self.cart = {}  # name -> [qty, unit_price]

        self._build_connection_bar()
        self._build_product_buttons()
        self._build_cart()
        self._build_log()

        self.after(100, self._poll_rx)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- UI ----------
    def _build_connection_bar(self):
        bar = ctk.CTkFrame(self)
        bar.pack(fill="x", padx=10, pady=(10, 6))

        self.port_box = ctk.CTkComboBox(bar, values=self._ports(), width=200)
        self.port_box.pack(side="left", padx=6, pady=8)
        if self.port_box.cget("values"):
            self.port_box.set(self.port_box.cget("values")[0])

        ctk.CTkButton(bar, text="Rafraichir", width=90,
                      command=self._refresh_ports).pack(side="left", padx=4)
        self.btn_conn = ctk.CTkButton(bar, text="Connecter", width=110,
                                      command=self._toggle_connection)
        self.btn_conn.pack(side="left", padx=4)
        self.lbl_status = ctk.CTkLabel(bar, text="Deconnecte", text_color="#c0392b")
        self.lbl_status.pack(side="left", padx=10)

    def _build_product_buttons(self):
        frame = ctk.CTkFrame(self)
        frame.pack(fill="x", padx=10, pady=6)
        ctk.CTkLabel(frame, text="Scanner un produit :").grid(
            row=0, column=0, columnspan=3, sticky="w", padx=6, pady=(6, 2))
        for i, (code, name, price) in enumerate(CATALOG):
            txt = f"{name}\n{price:.2f} EUR" if price else f"{name}\n(inconnu)"
            ctk.CTkButton(frame, text=txt, height=46, width=180,
                          command=lambda c=code: self.send_barcode(c)
                          ).grid(row=1 + i // 3, column=i % 3, padx=5, pady=5)

        entry_row = ctk.CTkFrame(self)
        entry_row.pack(fill="x", padx=10, pady=(0, 6))
        self.manual = ctk.CTkEntry(entry_row, placeholder_text="Code-barres manuel...")
        self.manual.pack(side="left", fill="x", expand=True, padx=6, pady=6)
        self.manual.bind("<Return>", lambda e: self._send_manual())
        ctk.CTkButton(entry_row, text="Envoyer", width=90,
                      command=self._send_manual).pack(side="left", padx=4)
        ctk.CTkButton(entry_row, text="Vider le panier", width=130, fg_color="#c0392b",
                      command=lambda: self.send_barcode("RESET")).pack(side="left", padx=4)

    def _build_cart(self):
        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=10, pady=6)
        cols = ("Article", "Qte", "P.U.", "Sous-total")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", height=6)
        for c, w in zip(cols, (240, 50, 80, 100)):
            self.tree.heading(c, text=c)
            self.tree.column(c, width=w, anchor="center")
        self.tree.column("Article", anchor="w")
        self.tree.pack(fill="both", expand=True, padx=6, pady=6)
        self.lbl_total = ctk.CTkLabel(frame, text="TOTAL : 0.00 EUR",
                                      font=ctk.CTkFont(size=18, weight="bold"))
        self.lbl_total.pack(anchor="e", padx=10, pady=(0, 6))

    def _build_log(self):
        self.log = ctk.CTkTextbox(self, height=90)
        self.log.pack(fill="x", padx=10, pady=(0, 10))
        self._log("Pret. Choisis un port COM puis Connecte.")

    # ---------- Serie ----------
    def _ports(self):
        return [p.device for p in list_ports.comports()]

    def _refresh_ports(self):
        vals = self._ports()
        self.port_box.configure(values=vals)
        if vals:
            self.port_box.set(vals[0])

    def _toggle_connection(self):
        if self.ser and self.ser.is_open:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        port = self.port_box.get()
        if not port:
            self._log("Aucun port COM selectionne.")
            return
        try:
            self.ser = serial.Serial(port, BAUD, timeout=0.2)
        except serial.SerialException as e:
            self._log(f"Erreur ouverture {port} : {e}")
            return
        self.running = True
        self.reader_thread = threading.Thread(target=self._reader, daemon=True)
        self.reader_thread.start()
        self.btn_conn.configure(text="Deconnecter")
        self.lbl_status.configure(text=f"Connecte ({port})", text_color="#27ae60")
        self._log(f"Connecte a {port} @ {BAUD} bauds.")

    def _disconnect(self):
        self.running = False
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.btn_conn.configure(text="Connecter")
        self.lbl_status.configure(text="Deconnecte", text_color="#c0392b")
        self._log("Deconnecte.")

    def _reader(self):
        """Thread de lecture : lit les lignes et les pousse dans la file."""
        buf = b""
        while self.running and self.ser and self.ser.is_open:
            try:
                data = self.ser.read(64)
            except Exception:
                break
            if data:
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    self.rx_queue.put(line.decode(errors="replace").strip())

    def send_barcode(self, code):
        if not (self.ser and self.ser.is_open):
            self._log("Pas connecte : impossible d'envoyer.")
            return
        try:
            self.ser.write((code + "\r").encode())      # CR = fin de trame (comme le scanner)
            self._log(f">> {code}")
        except Exception as e:
            self._log(f"Erreur envoi : {e}")

    def _send_manual(self):
        code = self.manual.get().strip()
        if code:
            self.send_barcode(code)
            self.manual.delete(0, "end")

    # ---------- Reception / panier ----------
    def _poll_rx(self):
        while not self.rx_queue.empty():
            self._handle_line(self.rx_queue.get())
        self.after(100, self._poll_rx)

    def _handle_line(self, line):
        if not line:
            return
        self._log(f"<< {line}")
        parts = line.split(";")
        if parts[0] == "FOUND" and len(parts) >= 3:
            name, price = parts[1], float(parts[2])
            if name in self.cart:
                self.cart[name][0] += 1
            else:
                self.cart[name] = [1, price]
            self._refresh_cart()
        elif parts[0] == "RESET":
            self.cart.clear()
            self._refresh_cart()

    def _refresh_cart(self):
        self.tree.delete(*self.tree.get_children())
        total = 0.0
        for name, (qty, pu) in self.cart.items():
            sub = qty * pu
            total += sub
            self.tree.insert("", "end", values=(name, qty, f"{pu:.2f}", f"{sub:.2f}"))
        self.lbl_total.configure(text=f"TOTAL : {total:.2f} EUR")

    # ---------- Divers ----------
    def _log(self, msg):
        self.log.insert("end", msg + "\n")
        self.log.see("end")

    def _on_close(self):
        self.running = False
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.destroy()


if __name__ == "__main__":
    PicMarketGUI().mainloop()
