@echo off
rem Lance l'interface PIC MARKET (double-clic sur ce fichier)
cd /d "%~dp0"
python pic_market_gui.py
rem Garde la fenetre ouverte en cas d'erreur
pause
