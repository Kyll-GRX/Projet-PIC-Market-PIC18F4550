/* ============================================================================
 *  glcd.h  -  Pilote GLCD 128x64 (contrôleur KS0108) pour EasyPIC v7
 *            Cible : PIC18F4550  /  Compilateur : XC8
 *
 *  Câblage EasyPIC v7 (relié en dur sur la carte) :
 *     - Bus de données D0..D7 ........ PORTD  (RD0..RD7)
 *     - CS1 (moitié gauche) .......... RB0
 *     - CS2 (moitié droite) .......... RB1
 *     - RS  (D/I : 0=cmd, 1=data) .... RB2
 *     - RW  (0=écriture, 1=lecture) .. RB3
 *     - EN  (strobe) ................. RB4
 *     - RST (reset, actif bas) ....... RB5
 * ==========================================================================*/
#ifndef GLCD_H
#define GLCD_H

#include <xc.h>
#include <stdint.h>

/* ---- Fréquence CPU : SEULE source de vérité (utilisée aussi par glcd.c) ---
 * Test simple  : quartz 8 MHz, oscillateur HS  -> 8000000
 * Projet USB   : quartz 8 MHz + PLL -> 48 MHz   -> 48000000
 * (les temporisations __delay s'ajustent automatiquement) */
#ifndef _XTAL_FREQ
#define _XTAL_FREQ 8000000UL
#endif

/* ------------------------- Mappage des broches ----------------------------*/
#define GLCD_DATA        LATD        /* écriture du bus de données */
#define GLCD_DATA_TRIS   TRISD       /* direction du bus de données */
#define GLCD_DATA_IN     PORTD       /* lecture du bus (busy flag) */

#define GLCD_CS1   LATBbits.LATB0
#define GLCD_CS2   LATBbits.LATB1
#define GLCD_RS    LATBbits.LATB2
#define GLCD_RW    LATBbits.LATB3
#define GLCD_EN    LATBbits.LATB4
#define GLCD_RST   LATBbits.LATB5

#define GLCD_CS1_TRIS  TRISBbits.TRISB0
#define GLCD_CS2_TRIS  TRISBbits.TRISB1
#define GLCD_RS_TRIS   TRISBbits.TRISB2
#define GLCD_RW_TRIS   TRISBbits.TRISB3
#define GLCD_EN_TRIS   TRISBbits.TRISB4
#define GLCD_RST_TRIS  TRISBbits.TRISB5

/* Niveau actif des chip-select.
 * EasyPIC v7 = actif HAUT (1 = puce sélectionnée).
 * Si une moitié de l'écran reste noire/vide, mets cette valeur à 0. */
#define GLCD_CS_ACTIVE  0

/* --------------------------- Dimensions -----------------------------------*/
#define GLCD_W      128
#define GLCD_HEIGHT 64
#define GLCD_PAGES  8            /* 64 lignes / 8 bits = 8 pages */

/* ------------------------------- API --------------------------------------*/
void GLCD_Init(void);                               /* reset + display ON    */
void GLCD_ClearScreen(void);                        /* tout éteint           */
void GLCD_FillScreen(uint8_t pattern);              /* 0xFF = tout allumé    */
void GLCD_GotoXY(uint8_t page, uint8_t col);        /* page 0..7, col 0..127 */
void GLCD_WriteChar(char c);                        /* caractère 5x7         */
void GLCD_WriteString(uint8_t page, uint8_t col, const char *s);

#endif /* GLCD_H */
