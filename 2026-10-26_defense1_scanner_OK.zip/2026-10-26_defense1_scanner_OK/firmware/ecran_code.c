/*
 * ecran_code.c - PIC MARKET (defense 1)
 * EasyPIC v7 - PIC18F4550 - XC8
 *
 * Chaine complete, simulee SANS le scanner :
 *   PC (Python) --USB-UART 9600 8N1--> RC7 (RX) --> PIC
 *   A la reception d'un code-barres (termine par CR = 0x0D) :
 *     - recherche du produit dans une petite base locale
 *     - affichage article + prix + total sur le GLCD
 *     - feedback : LED verte + bip 2.5 kHz (connu)
 *                  LED rouge + bip 1.5 kHz (inconnu)
 *     - renvoi du resultat au PC : "FOUND;nom;prix" ou "UNKNOWN;code"
 *
 * Quand le vrai scanner sera branche sur RC6/RC7 : RIEN a changer.
 * _XTAL_FREQ (8 MHz) est defini dans glcd.h.
 *
 * Brochage :
 *   GLCD .... PORTD (data) + RB0..RB5 (controle)   [voir glcd.h]
 *   UART .... RC6 (TX) / RC7 (RX)  -> module USB-UART de la carte
 *   Buzzer .. RC2 (PWM CCP1)
 *   LEDs .... RE0 (verte) / RE1 (rouge)
 */

/* ------------------------------ CONFIG BITS : 8 MHz HS ------------------- */
#pragma config PLLDIV   = 1
#pragma config CPUDIV   = OSC1_PLL2
#pragma config USBDIV   = 1
#pragma config FOSC     = HS        // quartz 8 MHz
#pragma config FCMEN    = OFF
#pragma config IESO     = OFF
#pragma config PWRT     = OFF
#pragma config BOR      = OFF
#pragma config BORV     = 3
#pragma config VREGEN   = OFF
#pragma config WDT      = OFF
#pragma config WDTPS    = 32768
#pragma config CCP2MX   = ON
#pragma config PBADEN   = OFF       // RB0..RB4 numeriques (controle GLCD)
#pragma config LPT1OSC  = OFF
#pragma config MCLRE    = ON
#pragma config STVREN   = ON
#pragma config LVP      = OFF       // RB5 utilisable (GLCD_RST)
#pragma config ICPRT    = OFF
#pragma config XINST    = OFF       // requis par XC8
#pragma config CP0 = OFF
#pragma config CP1 = OFF
#pragma config CP2 = OFF
#pragma config CP3 = OFF
#pragma config CPB = OFF
#pragma config CPD = OFF
#pragma config WRT0 = OFF
#pragma config WRT1 = OFF
#pragma config WRT2 = OFF
#pragma config WRT3 = OFF
#pragma config WRTB = OFF
#pragma config WRTC = OFF
#pragma config WRTD = OFF
#pragma config EBTR0 = OFF
#pragma config EBTR1 = OFF
#pragma config EBTR2 = OFF
#pragma config EBTR3 = OFF
#pragma config EBTRB = OFF

#include <xc.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "glcd.h"

/* 1 = relance le test GLCD du depart (meme sequence, en boucle)
 * 0 = firmware PIC MARKET complet */
#define MODE_TEST_GLCD  0

/* ------------------------------ Sorties --------------------------------- */
#define LED_GREEN   LATEbits.LATE0
#define LED_RED     LATEbits.LATE1
#define BUZZER      LATCbits.LATC2

/* Bouton "nouvelle transaction" (TS1.9) : RE2, PORTE en pull-down,
 * BUTTON PRESS LEVEL sur VCC -> appui = 1 */
#define BTN_RESET   PORTEbits.RE2
#define BTN_PRESSED 1

/* Duties PWM recalcules pour 8 MHz (50% de rapport cyclique) */
#define DUTY_2500HZ   25    /* produit connu   -> 2.5 kHz */
#define DUTY_1500HZ   42    /* produit inconnu -> 1.5 kHz */

/* ------------------------------ Reception UART -------------------------- */
#define RX_SIZE 32
static volatile char    rx_buf[RX_SIZE];
static volatile uint8_t rx_idx   = 0;
static volatile uint8_t rx_ready = 0;

/* ------------------------------ Base produits locale --------------------
 * Prix en centimes d'euro. Les memes codes servent de boutons cote Python. */
typedef struct { const char *code; const char *name; uint16_t cents; } product_t;

static const product_t catalog[] = {
    { "3017620422003", "Nutella 400g",    345 },
    { "5449000000996", "Coca-Cola 1.5L",  180 },
    { "3228857000906", "Baguette",         95 },
    { "8000500310427", "Kinder Bueno",    120 },
    { "20001",         "Pommes 1kg",      250 },
};
#define N_PRODUCTS (sizeof(catalog) / sizeof(catalog[0]))

static uint32_t total_cents = 0;

/* ============================== UART =================================== */
static void UART_Init(void)
{
    TRISCbits.TRISC7 = 1;    // RX en entree
    TRISCbits.TRISC6 = 0;    // TX en sortie
    TXSTAbits.SYNC   = 0;    // mode asynchrone
    TXSTAbits.BRGH   = 1;    // haute vitesse
    BAUDCONbits.BRG16 = 1;   // generateur 16 bits
    SPBRGH = 0;              // 8 MHz : SPBRG = 207 -> 9600 bauds
    SPBRG  = 207;            // 8e6 / (4*(207+1)) = 9615 ~ 9600
    TXSTAbits.TXEN = 1;      // emission ON
    RCSTAbits.SPEN = 1;      // port serie ON
    RCSTAbits.CREN = 1;      // reception continue ON
    PIE1bits.RCIE  = 1;      // interruption reception
}

static void UART_WriteByte(char c)
{
    while (!PIR1bits.TXIF);  // attend le buffer d'emission libre
    TXREG = c;
}

static void UART_WriteString(const char *s)
{
    while (*s) UART_WriteByte(*s++);
}

/* ======================= Interruption : reception ====================== */
void __interrupt() isr(void)
{
    if (PIR1bits.RCIF) {
        char c = RCREG;              // lit l'octet (efface RCIF)
        if (c == 0x0D) {             // CR = fin du code-barres
            rx_buf[rx_idx] = '\0';
            rx_ready = 1;
            rx_idx   = 0;
        } else if (c == 0x0A) {      // LF ignore (scanner regle en CR+LF)
        } else if (rx_idx < RX_SIZE - 1) {
            rx_buf[rx_idx++] = c;
        }
    }
    if (RCSTAbits.OERR) {            // overrun -> on relance la reception
        RCSTAbits.CREN = 0;
        RCSTAbits.CREN = 1;
    }
}

/* ============================== Buzzer (CCP1 / RC2) ==================== */
static void Buzzer_On(uint8_t duty)
{
    PR2     = (uint8_t)(2 * duty - 1);
    CCPR1L  = duty;
    CCP1CON = 0b00001100;    // mode PWM
    T2CON   = 0b00000111;    // prescaler 1:16 + Timer2 ON
}

static void Buzzer_Off(void)
{
    CCP1CON = 0x00;
    T2CON   = 0x00;
    BUZZER  = 0;
}

/* ============================== Feedbacks ============================== */
static void Feedback_OK(void)
{
    LED_GREEN = 1;
    Buzzer_On(DUTY_2500HZ);
    __delay_ms(100);         // TS2.6 : bip 100 ms @ 2.5 kHz
    Buzzer_Off();
    __delay_ms(1900);        // TS2.5 : LED verte 2 s au total
    LED_GREEN = 0;
}

static void Feedback_Unknown(void)
{
    LED_RED = 1;
    Buzzer_On(DUTY_1500HZ);
    __delay_ms(300);         // TS2.8 : bip 300 ms @ 1.5 kHz
    Buzzer_Off();
    __delay_ms(1700);        // TS2.7 : LED rouge 2 s au total
    LED_RED = 0;
}

/* ============================== Affichage GLCD ========================= */
static void Screen_Welcome(void)
{
    GLCD_ClearScreen();
    GLCD_WriteString(0, 0, "PIC MARKET");
    GLCD_WriteString(2, 0, "Scannez un produit");
    GLCD_WriteString(4, 0, "ou envoyez via PC");
}

static void Screen_Product(const char *name, uint16_t cents)
{
    char line[22];
    GLCD_ClearScreen();
    GLCD_WriteString(0, 0, "PIC MARKET");
    GLCD_WriteString(2, 0, name);
    sprintf(line, "Prix : %u.%02u EUR", cents / 100, cents % 100);
    GLCD_WriteString(3, 0, line);
    sprintf(line, "Total: %lu.%02lu EUR",
            (unsigned long)(total_cents / 100),
            (unsigned long)(total_cents % 100));
    GLCD_WriteString(5, 0, line);
}

static void Screen_Unknown(const char *code)
{
    GLCD_ClearScreen();
    GLCD_WriteString(0, 0, "PIC MARKET");
    GLCD_WriteString(2, 0, "PRODUIT INCONNU");
    GLCD_WriteString(3, 0, code);
}

/* ======================= Remise a zero du panier ======================= */
static void Cart_Reset(void)
{
    total_cents = 0;
    Screen_Welcome();
    UART_WriteString("RESET;OK\r\n");   // le GUI vide aussi son panier
}

/* ======================= Traitement d'un code-barres =================== */
static void Process(const char *code)
{
    char msg[48];

    /* Commande speciale depuis le PC : vider le panier */
    if (strcmp(code, "RESET") == 0) {
        Cart_Reset();
        return;
    }

    for (uint8_t i = 0; i < N_PRODUCTS; i++) {
        if (strcmp(code, catalog[i].code) == 0) {
            total_cents += catalog[i].cents;
            Screen_Product(catalog[i].name, catalog[i].cents);
            sprintf(msg, "FOUND;%s;%u.%02u\r\n",
                    catalog[i].name, catalog[i].cents / 100, catalog[i].cents % 100);
            UART_WriteString(msg);
            Feedback_OK();
            return;
        }
    }

    Screen_Unknown(code);
    sprintf(msg, "UNKNOWN;%s\r\n", code);
    UART_WriteString(msg);
    Feedback_Unknown();
}

/* ============================== main =================================== */
void main(void)
{
#if MODE_TEST_GLCD
    /* === Test GLCD du depart : sequence identique au test "Bienvenue" === */
    ADCON1 = 0x0F;
    CMCON  = 0x07;
    GLCD_Init();
    while (1) {
        GLCD_FillScreen(0xFF);  __delay_ms(1500);   // tous pixels ON : regle P3 ici
        GLCD_ClearScreen();     __delay_ms(500);
        GLCD_WriteString(0, 0, "PIC MARKET");
        GLCD_WriteString(1, 0, "GLCD 128x64 - KS0108");
        GLCD_WriteString(2, 0, "EasyPIC v7 + 18F4550");
        GLCD_WriteString(3, 0, "XC8 - test OK");
        GLCD_WriteString(5, 0, "0123456789");
        GLCD_WriteString(6, 0, "ABCDEFGHIJKLMNOPQRSTU");
        GLCD_WriteString(7, 0, "abcdefghijklmnopqrstu");
        __delay_ms(3000);
        GLCD_FillScreen(0xAA);  __delay_ms(1500);   // damiers
        GLCD_FillScreen(0x55);  __delay_ms(1500);
        GLCD_ClearScreen();     __delay_ms(500);
    }
#endif

    ADCON1 = 0x0F;           // toutes les broches numeriques
    CMCON  = 0x07;           // comparateurs off

    TRISEbits.TRISE0 = 0; LED_GREEN = 0;   // LED verte
    TRISEbits.TRISE1 = 0; LED_RED   = 0;   // LED rouge
    TRISCbits.TRISC2 = 0; BUZZER    = 0;   // buzzer
    TRISEbits.TRISE2 = 1;                  // bouton RE2 en entree

    UART_Init();

    __delay_ms(100);         // laisse le GLCD se stabiliser apres la mise sous tension
    GLCD_Init();
    GLCD_FillScreen(0xFF);   // test : tous les pixels ON 1 s (regle le contraste P3 ici)
    __delay_ms(1000);
    Screen_Welcome();

    /* Signal de demarrage : bip court + LED verte = le programme tourne */
    LED_GREEN = 1;
    Buzzer_On(DUTY_2500HZ);
    __delay_ms(100);
    Buzzer_Off();
    __delay_ms(400);
    LED_GREEN = 0;

    INTCONbits.PEIE = 1;     // interruptions peripheriques
    INTCONbits.GIE  = 1;     // interruptions globales

    UART_WriteString("PIC MARKET pret\r\n");

    while (1) {
        if (BTN_RESET == BTN_PRESSED) {         // bouton RE2 : vider le panier
            __delay_ms(30);                     // anti-rebond
            if (BTN_RESET == BTN_PRESSED) {
                Cart_Reset();
                while (BTN_RESET == BTN_PRESSED);   // attend le relachement
            }
        }

        if (rx_ready) {
            char code[RX_SIZE];
            INTCONbits.GIE = 0;             // copie atomique du buffer
            strcpy(code, (char *)rx_buf);
            rx_ready = 0;
            INTCONbits.GIE = 1;

            if (code[0] != '\0') Process(code);
        }
    }
}
