/*
 * mfrc522.c - Minimal MFRC522 driver for PIC18F4550 (XC8), software SPI
 * Reads 4-byte and 7-byte UIDs of ISO 14443-A cards (REQA, anticollision,
 * SELECT, HLTA). No authentication / sector reading: only the UID is used.
 */
#include "mfrc522.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 48000000UL
#endif

/* ---------- Software SPI, mode 0 (CPOL=0, CPHA=0), MSB first ---------- */
static uint8_t spi_xfer(uint8_t out)
{
    uint8_t in = 0;
    for (uint8_t i = 0; i < 8; i++) {
        RC522_MOSI = (out & 0x80) ? 1 : 0;   /* data set while SCK low     */
        out <<= 1;
        RC522_SCK = 1;                       /* RC522 samples on rising edge */
        in <<= 1;
        if (RC522_MISO) in |= 1;
        RC522_SCK = 0;                       /* RC522 shifts on falling edge */
    }
    return in;
}

/* Address byte: bit7 = 1 read / 0 write, bits 6..1 = address, bit0 = 0 */
static void reg_write(uint8_t addr, uint8_t val)
{
    RC522_SS = 0;
    spi_xfer((uint8_t)((addr << 1) & 0x7E));
    spi_xfer(val);
    RC522_SS = 1;
}

static uint8_t reg_read(uint8_t addr)
{
    uint8_t v;
    RC522_SS = 0;
    spi_xfer((uint8_t)(((addr << 1) & 0x7E) | 0x80));
    v = spi_xfer(0x00);
    RC522_SS = 1;
    return v;
}

/* CRC_A (ISO/IEC 14443-3 annex B), needed for SELECT and HLTA */
static uint16_t crc_a(const uint8_t *d, uint8_t n)
{
    uint16_t crc = 0x6363;
    while (n--) {
        uint8_t b = *d++;
        b ^= (uint8_t)(crc & 0xFF);
        b ^= (uint8_t)(b << 4);
        crc = (crc >> 8) ^ ((uint16_t)b << 8) ^ ((uint16_t)b << 3) ^ (b >> 4);
    }
    return crc;
}

/* Send tx[] to the card and collect the answer in rx[] */
static uint8_t transceive(const uint8_t *tx, uint8_t txLen,
                          uint8_t *rx, uint8_t rxMax, uint8_t *rxLen,
                          uint8_t lastBits)
{
    uint8_t irq, n, i;
    uint16_t guard = 3000;               /* software safety net only */

    reg_write(CommandReg, PCD_IDLE);
    reg_write(ComIrqReg, 0x7F);          /* clear all interrupt flags */
    reg_write(FIFOLevelReg, 0x80);       /* flush FIFO                */
    for (i = 0; i < txLen; i++) reg_write(FIFODataReg, tx[i]);
    reg_write(BitFramingReg, lastBits);  /* bits to send in last byte */
    reg_write(CommandReg, PCD_TRANSCEIVE);
    reg_write(BitFramingReg, (uint8_t)(0x80 | lastBits)); /* StartSend */

    for (;;) {
        irq = reg_read(ComIrqReg);
        if (irq & 0x30) break;                    /* RxIRq or IdleIRq   */
        if (irq & 0x01) return RC522_TIMEOUT;     /* TimerIRq: no answer */
        if (--guard == 0) return RC522_TIMEOUT;
    }
    if (reg_read(ErrorReg) & 0x1B)  /* BufferOvfl, CollErr, ParityErr, ProtocolErr */
        return RC522_ERR;

    n = reg_read(FIFOLevelReg);
    if (n > rxMax) return RC522_ERR;
    for (i = 0; i < n; i++) rx[i] = reg_read(FIFODataReg);
    *rxLen = n;
    return RC522_OK;
}

/* Anticollision + SELECT for one cascade level. out4 = 4 UID bytes of level */
static uint8_t select_level(uint8_t sel, uint8_t *out4, uint8_t *sak)
{
    uint8_t cmd[9], buf[5], n, i;
    uint16_t crc;

    cmd[0] = sel;  cmd[1] = 0x20;                      /* ANTICOLLISION */
    if (transceive(cmd, 2, buf, 5, &n, 0) != RC522_OK || n != 5) return RC522_ERR;
    if ((uint8_t)(buf[0] ^ buf[1] ^ buf[2] ^ buf[3]) != buf[4]) return RC522_ERR; /* BCC */

    cmd[1] = 0x70;                                     /* SELECT */
    for (i = 0; i < 5; i++) cmd[2 + i] = buf[i];
    crc = crc_a(cmd, 7);
    cmd[7] = (uint8_t)(crc & 0xFF);
    cmd[8] = (uint8_t)(crc >> 8);
    if (transceive(cmd, 9, buf, 3, &n, 0) != RC522_OK || n != 3) return RC522_ERR;

    *sak = buf[0];
    for (i = 0; i < 4; i++) out4[i] = cmd[2 + i];
    return RC522_OK;
}

void RC522_Init(void)
{
    /* RA0..RA3, RA5 as digital I/O. If ADCON1/CMCON are set in your system
       init, do it there instead and remove these two lines. */
    ADCON1 = 0x0F;
    CMCON  = 0x07;

    RC522_SS_TRIS = 0;  RC522_SCK_TRIS = 0;  RC522_MOSI_TRIS = 0;
    RC522_RST_TRIS = 0; RC522_MISO_TRIS = 1;
    RC522_SS = 1;  RC522_SCK = 0;  RC522_MOSI = 0;

    RC522_RST = 0;  __delay_ms(2);           /* hard reset */
    RC522_RST = 1;  __delay_ms(50);
    reg_write(CommandReg, PCD_SOFTRESET);
    __delay_ms(50);

    /* Internal timer = receive timeout.
       f = 13.56 MHz / (2*0xD3E + 1) ~ 2 kHz -> 0.5 ms per tick, reload 10 -> ~5 ms */
    reg_write(TModeReg, 0x8D);        /* TAuto=1, prescaler high nibble 0xD */
    reg_write(TPrescalerReg, 0x3E);
    reg_write(TReloadRegH, 0x00);
    reg_write(TReloadRegL, 10);

    reg_write(TxASKReg, 0x40);        /* force 100 % ASK modulation */
    reg_write(ModeReg, 0x3D);         /* CRC preset 0x6363          */

    uint8_t tx = reg_read(TxControlReg);
    if ((tx & 0x03) != 0x03) reg_write(TxControlReg, (uint8_t)(tx | 0x03)); /* antenna on */
}

uint8_t RC522_Version(void)
{
    return reg_read(VersionReg);
}

uint8_t RC522_ReadCard(rc522_card_t *c)
{
    uint8_t cmd[4], atqa[2], part[4], n, sak, i;
    uint16_t crc;

    cmd[0] = PICC_REQA;                                  /* 7-bit short frame */
    if (transceive(cmd, 1, atqa, 2, &n, 0x07) != RC522_OK || n != 2)
        return RC522_NOCARD;

    if (select_level(PICC_SEL_CL1, part, &sak) != RC522_OK) return RC522_ERR;

    if (part[0] == 0x88) {                     /* cascade tag: 7-byte UID */
        for (i = 0; i < 3; i++) c->uid[i] = part[1 + i];
        if (select_level(PICC_SEL_CL2, part, &sak) != RC522_OK) return RC522_ERR;
        for (i = 0; i < 4; i++) c->uid[3 + i] = part[i];
        c->len = 7;
    } else {                                   /* 4-byte UID (student card) */
        for (i = 0; i < 4; i++) c->uid[i] = part[i];
        c->len = 4;
    }
    c->sak = sak;

    /* HLTA: card goes to HALT and ignores REQA until removed from field.
       A correct HLTA gets no answer, so the timeout here is expected. */
    cmd[0] = PICC_HLTA;  cmd[1] = 0x00;
    crc = crc_a(cmd, 2);
    cmd[2] = (uint8_t)(crc & 0xFF);
    cmd[3] = (uint8_t)(crc >> 8);
    (void)transceive(cmd, 4, atqa, 2, &n, 0);

    return RC522_OK;
}
