/*
 * mfrc522.h - Minimal MFRC522 driver for PIC18F4550 (XC8), software SPI
 * PIC-MARKET project
 *
 * Why software SPI: on the PIC18F4550 the MSSP SDO output is RC7, which is
 * also the EUSART RX pin used by the barcode scanner (TS2.3). The MSSP is
 * therefore kept for I2C (RTC, TS1.11) and the RC522 is driven by GPIO.
 *
 * Wiring (PIC is at 5 V, RC522 module is 3.3 V):
 *   RC522 pin   PIC pin  Direction      Level shifting
 *   SDA (SS)    RA0      PIC -> RC522   divider 2.2k series / 3.3k to GND
 *   SCK         RA1      PIC -> RC522   divider 2.2k / 3.3k
 *   MOSI        RA2      PIC -> RC522   divider 2.2k / 3.3k
 *   MISO        RA3      RC522 -> PIC   direct (RA3 is a TTL input, VIH ~2.0 V)
 *   RST         RA5      PIC -> RC522   divider 2.2k / 3.3k
 *   IRQ         n.c.     (polling)
 *   3.3V        3.3 V rail of the EasyPIC v7
 *   GND         GND (common)
 * Adapt the macros below if your allocation table uses other pins.
 * Keep MISO on a TTL-buffer input (PORTB, RA0-RA3, RA5): Schmitt-trigger
 * inputs (PORTC, PORTE...) need 0.8*VDD = 4 V and will not see 3.3 V as '1'.
 *
 * Requires _XTAL_FREQ to be defined to the CPU clock (48000000 with USB PLL).
 */
#ifndef MFRC522_H
#define MFRC522_H

#include <xc.h>
#include <stdint.h>

/* ---------- Pin mapping ---------- */
#define RC522_SS         LATAbits.LATA0
#define RC522_SCK        LATAbits.LATA1
#define RC522_MOSI       LATAbits.LATA2
#define RC522_MISO       PORTAbits.RA3
#define RC522_RST        LATAbits.LATA5

#define RC522_SS_TRIS    TRISAbits.TRISA0
#define RC522_SCK_TRIS   TRISAbits.TRISA1
#define RC522_MOSI_TRIS  TRISAbits.TRISA2
#define RC522_MISO_TRIS  TRISAbits.TRISA3
#define RC522_RST_TRIS   TRISAbits.TRISA5

/* ---------- MFRC522 registers (datasheet section 9) ---------- */
#define CommandReg       0x01
#define ComIrqReg        0x04
#define ErrorReg         0x06
#define FIFODataReg      0x09
#define FIFOLevelReg     0x0A
#define BitFramingReg    0x0D
#define ModeReg          0x11
#define TxControlReg     0x14
#define TxASKReg         0x15
#define TModeReg         0x2A
#define TPrescalerReg    0x2B
#define TReloadRegH      0x2C
#define TReloadRegL      0x2D
#define VersionReg       0x37

/* ---------- MFRC522 commands ---------- */
#define PCD_IDLE         0x00
#define PCD_TRANSCEIVE   0x0C
#define PCD_SOFTRESET    0x0F

/* ---------- ISO 14443-A card commands ---------- */
#define PICC_REQA        0x26
#define PICC_SEL_CL1     0x93
#define PICC_SEL_CL2     0x95
#define PICC_HLTA        0x50

/* ---------- Return codes ---------- */
#define RC522_OK         0
#define RC522_NOCARD     1
#define RC522_ERR        2
#define RC522_TIMEOUT    3

/* SAK values useful to identify the card family */
#define SAK_MIFARE_1K    0x08   /* student card, most school tags      */
#define SAK_MIFARE_4K    0x18
#define SAK_ISO_DEP      0x20   /* bank cards / phones (EMV)           */
#define SAK_ULTRALIGHT   0x00   /* NTAG stickers, Ultralight            */

typedef struct {
    uint8_t uid[7];
    uint8_t len;     /* 4 or 7 */
    uint8_t sak;
} rc522_card_t;

void    RC522_Init(void);
uint8_t RC522_Version(void);             /* 0x91 / 0x92 for genuine chips   */
uint8_t RC522_ReadCard(rc522_card_t *c); /* RC522_OK when a card was read    */

/*
 * Suggested USB HID messages (64-byte reports), adapt to your protocol:
 *   PIC -> PC  [0]=0x20 CARD_DETECTED  [1]=context (1=identify, 2=payment)
 *              [2]=SAK  [3]=uid length  [4..10]=UID bytes
 *   PC -> PIC  [0]=0x21 CARD_RESULT    [1]=0 unknown,1 loyalty,2 student,
 *              3 payment accepted,4 payment refused   [2]=discount %
 *
 * Usage in the FSM (poll every ~100 ms from a timer flag, only in states
 * where a card is expected):
 *
 *   case ST_IDENTIFY:
 *     if (rfid_tick) {
 *       rfid_tick = 0;
 *       if (RC522_ReadCard(&card) == RC522_OK) send_card_report(1, &card);
 *     }
 *     break;
 *
 * The card is put in HALT after each read, so it is not read again until it
 * leaves the field: this is the anti double-scan for cards.
 */

#endif
