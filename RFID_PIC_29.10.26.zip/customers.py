"""
customers.py - Customer / student-card registry and discount rules (PIC-MARKET GUI)

A card is recognised as a student card because its UID is registered with
is_student = 1 (whitelist). Data is stored in SQLite so it survives a restart
of the application (TS4.11). Amounts are handled in cents to avoid float errors.

Discount rule (design choice, document it in the report):
  - student card            -> 20 % on the whole cart
  - loyalty >= 100 points   -> 5 %  (TS4.9)
  - discounts are NOT cumulative: the best one applies
  - loyalty points: 1 point per euro actually paid (TS4.8)
"""
import sqlite3
from dataclasses import dataclass

DB_PATH = "picmarket.db"
STUDENT_RATE_PCT = 20
LOYALTY_RATE_PCT = 5
LOYALTY_THRESHOLD = 100

# USB HID protocol (must match mfrc522.h)
CMD_CARD_DETECTED = 0x20
CMD_CARD_RESULT = 0x21
CTX_IDENTIFY, CTX_PAYMENT = 1, 2
RES_UNKNOWN, RES_LOYALTY, RES_STUDENT, RES_PAY_OK, RES_PAY_REFUSED = 0, 1, 2, 3, 4


@dataclass
class Customer:
    uid: str
    name: str
    is_student: bool
    points: int


def uid_to_hex(uid_bytes) -> str:
    """b'\\x43\\xa9\\x4a\\xaa' -> '43A94AAA' (same byte order as NFC Tools on Android)."""
    return bytes(uid_bytes).hex().upper()


def init_db(path: str = DB_PATH) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.execute(
        """CREATE TABLE IF NOT EXISTS customers(
               uid        TEXT PRIMARY KEY,
               name       TEXT NOT NULL,
               is_student INTEGER NOT NULL DEFAULT 0,
               points     INTEGER NOT NULL DEFAULT 0)"""
    )
    con.commit()
    return con


def register(con, uid_hex: str, name: str, is_student: bool = False) -> None:
    """Add or update a card. Existing points are kept."""
    uid_hex = uid_hex.replace(" ", "").replace(":", "").upper()
    con.execute(
        """INSERT INTO customers(uid, name, is_student) VALUES(?, ?, ?)
           ON CONFLICT(uid) DO UPDATE SET name = excluded.name,
                                          is_student = excluded.is_student""",
        (uid_hex, name, int(is_student)),
    )
    con.commit()


def lookup(con, uid_hex: str):
    row = con.execute(
        "SELECT uid, name, is_student, points FROM customers WHERE uid = ?",
        (uid_hex.upper(),),
    ).fetchone()
    return Customer(row[0], row[1], bool(row[2]), row[3]) if row else None


def compute_bill(subtotal_cents: int, customer) -> dict:
    """Best discount wins. Returns everything the invoice needs (TS4.4, TS4.10)."""
    rate, label = 0, "None"
    if customer is not None:
        if customer.is_student and STUDENT_RATE_PCT > rate:
            rate, label = STUDENT_RATE_PCT, f"Student -{STUDENT_RATE_PCT}%"
        if customer.points >= LOYALTY_THRESHOLD and LOYALTY_RATE_PCT > rate:
            rate, label = LOYALTY_RATE_PCT, f"Loyalty -{LOYALTY_RATE_PCT}%"
    discount = (subtotal_cents * rate + 50) // 100          # rounded to the cent
    total = subtotal_cents - discount
    return {
        "subtotal": subtotal_cents,
        "rate_pct": rate,
        "label": label,
        "discount": discount,
        "total": total,
        "points_earned": total // 100 if customer else 0,  # 1 pt per full euro
    }


def add_points(con, uid_hex: str, points: int) -> None:
    """Call only after an ACCEPTED payment."""
    con.execute("UPDATE customers SET points = points + ? WHERE uid = ?", (points, uid_hex))
    con.commit()


# ---------- HID helpers ----------
def parse_card_report(report):
    """report = list/bytes read from the PIC. Returns (context, sak, uid_hex) or None."""
    if not report or report[0] != CMD_CARD_DETECTED:
        return None
    ctx, sak, n = report[1], report[2], report[3]
    if n not in (4, 7):
        return None
    return ctx, sak, uid_to_hex(report[4:4 + n])


def build_card_result(customer, rate_pct: int) -> bytes:
    """64-byte answer to the PIC. With hidapi: dev.write(b'\\x00' + report)."""
    if customer is None:
        kind = RES_UNKNOWN
    else:
        kind = RES_STUDENT if customer.is_student else RES_LOYALTY
    rep = bytearray(64)
    rep[0], rep[1], rep[2] = CMD_CARD_RESULT, kind, rate_pct
    return bytes(rep)


if __name__ == "__main__":
    con = init_db(":memory:")
    register(con, "43 A9 4A AA", "Student demo card", is_student=True)

    # Simulated report from the PIC: identification context, SAK 0x08 (MIFARE 1K)
    fake = bytes([CMD_CARD_DETECTED, CTX_IDENTIFY, 0x08, 4, 0x43, 0xA9, 0x4A, 0xAA])
    ctx, sak, uid = parse_card_report(fake)
    cust = lookup(con, uid)
    bill = compute_bill(2350, cust)                       # 23.50 EUR cart
    print(uid, int(uid, 16), cust)
    print(bill)
    print(build_card_result(cust, bill["rate_pct"])[:3].hex())
